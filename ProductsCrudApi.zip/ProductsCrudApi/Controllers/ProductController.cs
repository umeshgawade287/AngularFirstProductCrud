﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using ProductsCrudApi.Models;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace ProductsCrudApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        readonly IConfiguration _configuration;
        readonly ProductsDbContext _dbContext;
        readonly IProductsService _productservice;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ProductController(IConfiguration configuration,ProductsDbContext dbContext,IProductsService productservice,IWebHostEnvironment webHostEnvironment)
        {
            _configuration= configuration;
            _dbContext= dbContext;
            _productservice= productservice;
            _productservice.Configuration= _configuration;
            _productservice.dbContext= _dbContext;
            _webHostEnvironment = webHostEnvironment;
        }        

        [HttpGet]
        [Route("[action]")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<IEnumerable<Products>> GetAll()
        {
            var products = _productservice.getAllProducts();
            if (products.Count() <=0 )
            {
                return NotFound(products);
            }
            else
            {
                return Ok(products);
            }
        }

        [HttpGet("{id:int:min(1)}",Name ="GetProduct")]
        [ProducesResponseType(typeof(Products), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetById(int id)
        {
            var product=_productservice.getProductById(id);
            if (product == null)
               {
                return NotFound();
            }
            else
            {
                return Ok(product);
            }
        }

        //[Authorize]
        [HttpPost,DisableRequestSizeLimit]
        public IActionResult Create(Products product)
        {

            bool success;
            //var file = product.image;
            //string filename = UploadProductImage(file);
            Products prod = new Products();
            //prod.image = filename;
            prod.name = product.name;
            prod.description = product.description;
            prod.price = product.price;
            prod.quantity = product.quantity;
            success = _productservice.createProduct(prod);

            if (success == true)
            {
                return CreatedAtAction("GetById", new { id = prod.id }, prod);
            }
            else
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
        }


        //[Authorize]
        [HttpPut]
        public IActionResult Update([FromQuery]int id,Products product)
        {
            bool success;
            if(product==null | id!=product.id)
            {
                return BadRequest();
            }
            var prod= _productservice.getProductById(id);
            if(prod == null)
            {
                return NotFound();
            }

            prod.name = product.name;
            prod.description = product.description;
            prod.price = product.price;
            prod.quantity = product.quantity;
            //var file = product.image;
            //string filename = UploadProductImage(file);
            //if(filename!=null)
            //{
            //    prod.image = filename;
            //}
            success = _productservice.updateProduct(id, prod);
            if (success == true)
            {
                return CreatedAtAction("GetById", new { id = product.id }, prod);
            }
            else
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
        }

        //[Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            bool success;
            var product = _productservice.getProductById(id);
            if (product == null)
            {
                return NotFound();
            }
            success = _productservice.deleteProduct(product);
            if (success == true)
            {
                return Ok(new {message="Deleted"});
            }
            else
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
        }

        [NonAction]
        private string UploadProductImage(IFormFile file)
        {
            string fileName = null;

            if (file != null)
            {
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "..//wwwroot//Images");
                fileName = Guid.NewGuid().ToString() + "_" + file.FileName;
                string filePath = Path.Combine(uploadsFolder, fileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
            }
            return fileName;
        }

    }
}
