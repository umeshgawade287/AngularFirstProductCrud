﻿using System.Collections;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace ProductsCrudApi.Models
{
    public interface IProductsService
    {
        public IConfiguration Configuration { get; set; }
        public ProductsDbContext dbContext { get; set; }
        bool createProduct(Products product);
        IEnumerable<Products> getAllProducts();
        Products getProductById(int id);
        bool updateProduct(int id,Products product);
        bool deleteProduct(Products product);

    }

    public class ProductsService : IProductsService
    {
        public IConfiguration Configuration { get; set; }
        public ProductsDbContext dbContext { get; set; }

        public bool createProduct(Products product)
        {
            try
            {
                dbContext.Add(product);
                dbContext.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public IEnumerable<Products> getAllProducts()
        {
            return dbContext.Products.ToList();
        }

        public Products getProductById(int id)
        {
            return dbContext.Products.Where(x=>x.id == id).FirstOrDefault();
        }

        public bool updateProduct(int id,Products product)
        {
            try
            {
                dbContext.Products.Update(product);
                dbContext.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool deleteProduct(Products product)
        {
            try
            {
                dbContext.Products.Remove(product);
                dbContext.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}
