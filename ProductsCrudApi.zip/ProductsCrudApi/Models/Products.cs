﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductsCrudApi.Models
{
    [Table("ProductMaster")]
    public class Products
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        [Required]
        public string name { get; set; }
        [Required]
        public string description { get; set; }
        public string image { get; set; }
        [Required]
        public decimal price { get; set; }
        [Required]
        public decimal quantity { get; set; }

    }
}
