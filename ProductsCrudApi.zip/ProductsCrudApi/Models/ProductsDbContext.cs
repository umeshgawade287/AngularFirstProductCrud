﻿

using Microsoft.EntityFrameworkCore;

namespace ProductsCrudApi.Models
{
    public class ProductsDbContext : DbContext
    {
        
        public ProductsDbContext(DbContextOptions<ProductsDbContext> options) :base(options)
        {

        }
        public DbSet<Products> Products { get; set; }


    }
}
